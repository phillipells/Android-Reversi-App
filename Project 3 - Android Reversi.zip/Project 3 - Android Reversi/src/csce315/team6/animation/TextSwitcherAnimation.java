package csce315.team6.animation;

/*public class TextSwitcherAnimation extends Activity implements ViewSwitcher.ViewFactory, 
	View.OnClick Listener{

}
*/