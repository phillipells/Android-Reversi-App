/** Automatically generated file. DO NOT MODIFY */
package csce315.team6.reversi;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}